
import pygame
import math

STOPPED = -1
UP = 0
DOWN = 1
LEFT = 2
RIGHT = 3

class Snake:
    def __init__(self, screen):
        self.snakesize = 2
        self.direction = STOPPED # That define the focus direction of snake
        self.screen = screen

        self.velocity = 0.1

        # Parameter for render style
        self.color = (180, 246, 206)
        self.blocksize = 30
        # Snake body
        self.body = [(self.blocksize, self.blocksize), (self.blocksize, self.blocksize)]

    def calculatePos(self):
        # New head position:
        if not self.direction == STOPPED:
            headX = 0
            headY = 0
            if self.direction == UP:
                headX = self.body[0][0]
                headY = self.body[0][1] - math.ceil(self.blocksize*self.velocity)# y - 1
            elif self.direction == DOWN:
                headX = self.body[0][0]
                headY = self.body[0][1] + math.floor(self.blocksize*self.velocity) # y + 1
            elif self.direction == LEFT:
                headX = self.body[0][0] - math.ceil(self.blocksize*self.velocity) # x - 1
                headY = self.body[0][1]
            elif self.direction == RIGHT:
                headX = self.body[0][0] + math.floor(self.blocksize*self.velocity) # x + 1
                headY = self.body[0][1]


            self.body.pop()
            self.body.insert(0, (headX, headY))

    def render(self):
        for part in self.body:
            pygame.draw.rect(self.screen, self.color, pygame.Rect(part[0], part[1], self.blocksize-10, self.blocksize-10))

    def eat(self):
        newTail = self.body[-1]
        self.body.append(newTail)
        self.snakesize += 1
