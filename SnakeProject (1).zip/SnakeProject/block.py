
class Block:
    def __init__(self):
        self.size = 10
