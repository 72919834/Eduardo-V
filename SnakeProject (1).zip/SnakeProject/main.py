import pygame

import snake # File snake.py
import food # File food.py

PAUSED = 0
RUN = 1
GAMEOVER = 2

done = False


pygame.init()
pygame.display.set_caption("Snake UTEC 2017")
screen = pygame.display.set_mode((400, 300))
font = pygame.font.SysFont("monospace", 20)


s = snake.Snake(screen)
food = food.Food(screen)
gamestate = PAUSED

def checkWallBounding():
    snakeHeadX = s.body[0][0]
    snakeHeadY = s.body[0][1]
    print "i"
    if snakeHeadX >= screen.get_width()-s.blocksize or snakeHeadX <= 0:
        print "a"
        return True

    if snakeHeadY >= screen.get_height()-s.blocksize/2 or snakeHeadY <= 0:
        print "b"
        return True

    return False

clock = pygame.time.Clock()

while not done:

    screen.fill((37, 50, 55))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        if event.type == pygame.KEYDOWN:
            if not gamestate == GAMEOVER:
                if event.key == pygame.K_LEFT:
                    if not s.direction == snake.RIGHT:
                        s.direction = snake.LEFT
                        gamestate = RUN
                if event.key == pygame.K_RIGHT:
                    if not s.direction == snake.LEFT:
                        s.direction = snake.RIGHT
                        gamestate = RUN
                if event.key == pygame.K_UP:
                    if not s.direction == snake.DOWN:
                        s.direction = snake.UP
                        gamestate = RUN
                if event.key == pygame.K_DOWN:
                    if not s.direction == snake.UP:
                        s.direction = snake.DOWN
                        gamestate = RUN
            else:
                if event.key == pygame.K_SPACE:
                    s = snake.Snake(screen)
                    gamestate = PAUSED

    s.calculatePos()
    s.render()

    if food.detectCollision(snake=s):
        food.generateNew()
        s.eat()
    food.render()

    if gamestate == PAUSED:
        label = font.render("Use the arrows to move...", 1, (255,255,0))
        center = label.get_rect().center
        screen.blit(label, (screen.get_width()/2-center[0], screen.get_height()/2-center[1]))
    elif gamestate == GAMEOVER:
        label = font.render("GAME OVER, SCORE: " + str(s.snakesize), 1, (255,255,0))
        center = label.get_rect().center
        screen.blit(label, (screen.get_width()/2-center[0], screen.get_height()/2-center[1]))

    if checkWallBounding() == True:
        s.direction = snake.STOPPED
        gamestate = GAMEOVER
    pygame.display.flip()
    clock.tick(60)
