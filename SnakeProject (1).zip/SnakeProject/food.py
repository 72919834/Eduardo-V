import pygame

import random

class Food:

    def __init__(self, screen):
        self.screen = screen
        self.color = (255, 137, 131)
        self.state = 0
        self.size = 20
        self.x = (self.screen.get_width()-20)*random.random() + 10
        self.y = (self.screen.get_height()-20)*random.random() + 10


    def generateNew(self):
        self.x = (self.screen.get_width()-20)*random.random() + 10
        self.y = (self.screen.get_height()-20)*random.random() + 10

    def render(self):
        pygame.draw.rect(self.screen, self.color, pygame.Rect(self.x, self.y, self.size, self.size))

    def detectCollision(self, snake):
        snakeHeadX = snake.body[0][0]
        snakeHeadY = snake.body[0][1]
        if snakeHeadX <= self.x + self.size and snakeHeadX >= self.x - self.size:
            if snakeHeadY <= self.y + self.size and snakeHeadY >= self.y - self.size:
                return True

        return False
